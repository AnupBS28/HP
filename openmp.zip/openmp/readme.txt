Run commands
$ gcc <file.c> -openmp
$ ./a.out