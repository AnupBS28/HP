This contains all 3 exercises. 
Run using python file.py in cmd 
or
in vs code debugger.