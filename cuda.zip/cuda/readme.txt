Run Commands
$ nvcc <file.cu>
$ ./a.out