#include <iostream>
#include <mutex>
#include <stdio.h>
#include <thread>
#include<vector>
#include<semaphore.h>
using namespace std;

#define n 5
int balance=0;
sem_t read;
sem_t write;
mutex forkLock[n];

void reader(int philosopher_no);
void writer(int philosopher_no);

mutex lock1;
int main()
{	
	
    vector<thread> threadList ;
    int x=9;
    for(int i=0;i<x;i++){
        //cout<<i <<endl;
        if(i%2==0 or i%3==0){
        threadList.push_back(thread(reader,i));
        }
        else{
            threadList.push_back(thread(writer,i));
        }
    }
    //cout<<"dadsout\n";
    for(int i=0;i<x;i++){
        threadList[i].join();
    }

	
}
void reader(int philosopher_no)
{
    //cout<<"dasds";
	sem_wait(&read);
	sem_wait(&write);
	lock1.lock();
	cout<<"Thread "<<philosopher_no<<" has completed reading , balance value : "<<balance<<endl;
	lock1.unlock();
	sem_post(&write);
	sem_post(&read);

}

void writer(int philosopher_no)
{
    //cout<<"dasds12";
	sem_wait(&read);
	sem_wait(&write);
    balance+=1;
	lock1.lock();
	cout<<"thread "<<philosopher_no<<"has completed writing. Updated Balance: "<<balance<<endl;
	lock1.unlock();
	sem_post(&write);
	sem_post(&read);

}
