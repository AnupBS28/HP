#include<iostream>
#include<thread>
#include<stdlib.h>
#include<chrono>
#include<mutex>
#include<vector>
#include <cstdlib>
#include<condition_variable>
using namespace std;

condition_variable emp;
condition_variable av;
mutex add,p,c;

vector <int> values;

int stop = 0;
int total = 0;


void prod(){
	while(total<10&&values.size()<5){
		unique_lock(<mutex> lck2(c));
		emp.wait(lck2);
		add.lock();
		values.push_back(total);
		cout<<"P"<<total<<endl;
		total+=1;
		add.unlock();
		av.notify_one();
	}
	stop = 1
}

void consume(){
	emp.notify_one();
	while(!stop){
		unique_lock(<mutex> lck(p));
		av.wait(lck);
		add.lock();
		cout<<"C: "<<values[0]<<endl;
		add.unlock();
		int x = values.begin();
		values.erase(x);
		if(values.size()>=1){
			av.notify_one();
		}
		emp.notify_one();
	}
}

int main(){
    thread t[2];
    t[0] = thread(&prod);
    t[1] = thread(&consume);
    for(int i=0;i<2;i++)
      t[i].join();
    return 0;
}
