#include <iostream>
#include <mutex>
#include <stdio.h>
#include <thread>
#include<vector>
using namespace std;

#define n 5

mutex forkLock[n];


void dining_philosopher(int philosopher_no);
mutex lock1;
int main()
{	
	
    vector<thread> threadList ;
    for(int i=0;i<5;i++){
        threadList.push_back(thread(dining_philosopher,i));
    }
    for(int i=0;i<5;i++){
        threadList[i].join();
    }

	
}
void dining_philosopher(int philosopher_no)
{
	if(philosopher_no > 0)
	{
        forkLock[philosopher_no-1].lock();
		forkLock[philosopher_no].lock();
		lock1.lock();
		cout<<"Philosopher "<<philosopher_no<<" Now has both fork to eat"<<endl;
		lock1.unlock();
		forkLock[philosopher_no-1].unlock();
		forkLock[philosopher_no].unlock();

		
	}
	else
	{
	    forkLock[0].lock();
		forkLock[4].lock();
		lock1.lock();
		cout<<"Philosopher "<<philosopher_no<<" Now has both fork to eat"<<endl;
		lock1.unlock();
		forkLock[0].unlock();
		forkLock[4].unlock();	
	}

}
