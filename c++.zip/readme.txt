Run commands:
$ g++ <file.cpp> -lpthread
$ ./a.out

