1.exe1.java
2.CustomThread_2.java
3.MyRunnable_3.java
4.InterruptExample_4.java
5.JoinExample_5.java
6.Bank_6.java
Open Each file in visual studio code and then go to run section and choose run and debug.(click proceed even if you get any build failed errors)